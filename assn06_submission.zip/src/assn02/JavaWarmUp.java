package assn02;

import java.util.Scanner;

// Here is a starter code that you may optionally use for this assignment.
// TODO: You need to complete these sections

public class JavaWarmUp {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        String[] categoriesList = {"phone", "laptop", "smart_watch"};

        int n = s.nextInt();
        // MM/DD/YY, HH:MM, Name, Price, Quantity, Rating, Duration

        // create corresponding size arrays
        String[] dateT = new String[n];
        String[] timeT = new String[n];
        String[] categoryT = new String[n];
        double[] Assembling_fee = new double[n];
        int[] quantityT = new int[n];
        double[] Assembling_Time = new double[n];
        double[] Energy_and_Device_Cost = new double[n];

        // TODO: Fill in the above arrays with data entered from the console.
        // Your code starts here:
        for (int i = 0; i < n; i++) {
            dateT[i] = s.next();
            timeT[i] = s.next();
            categoryT[i] = s.next();
            Assembling_fee[i] = s.nextDouble();
            quantityT[i] = s.nextInt();
            Assembling_Time[i] = s.nextDouble();
            Energy_and_Device_Cost[i] = s.nextDouble();
        }
        // Your code ends here.

        // Find items with highest and lowest price per unit
        int highestItemIndex = getMaxPriceIndex(Assembling_fee);
        int lowestItemIndex = getMinPriceIndex(Assembling_fee);

        // TODO: Print items with highest and lowest price per unit.
        // Your code starts here:
        System.out.println("\n" + dateT[highestItemIndex]);
        System.out.println(timeT[highestItemIndex]);
        System.out.println(categoryT[highestItemIndex]);
        System.out.println(Assembling_fee[highestItemIndex]);

        System.out.println(dateT[lowestItemIndex]);
        System.out.println(timeT[lowestItemIndex]);
        System.out.println(categoryT[lowestItemIndex]);
        System.out.println(Assembling_fee[lowestItemIndex]);
        // Your code ends here.

        // Calculate the average price, rating and duration of sales by category.
        // Maintain following category-wise stats in Arrays
        int[] numOfCategoriesC = new int[categoriesList.length];// so number of units in each category
        double[] totPriceC = new double[categoriesList.length]; // total price of each category = sum(price x qty)
        int[] totQuantityC = new int[categoriesList.length];    // total qty of each category = sum (qty)
        double[] totAssembling_TimeC = new double[categoriesList.length]; // calculate total assembling wage for each category.
        double[] totEnergy_and_Device_CostC = new double[categoriesList.length]; //  total Energy_and_Device_Cost for each category.

        // TODO: set the value of catIndex for each i to be such that categoryT[i] == categoriesList[i].
        // Your code starts here:
        for (int i = 0; i < n; i++) {
            switch (categoryT[i]) {
                case "phone" -> numOfCategoriesC[0]++;
                case "laptop" -> numOfCategoriesC[1]++;
                case "smart_watch" -> numOfCategoriesC[2]++;
            }
        }
        for (int i = 0; i < n; i++) {
            switch (categoryT[i]) {
                case "phone" -> totAssembling_TimeC[0] += Assembling_Time[i];
                case "laptop" -> totAssembling_TimeC[1] += Assembling_Time[i];
                case "smart_watch" -> totAssembling_TimeC[2] += Assembling_Time[i];

            }
        }
        for (int i = 0; i < n; i++) {
            switch (categoryT[i]) {
                case "phone" -> totPriceC[0] += Assembling_fee[i] * quantityT[i];
                case "laptop" -> totPriceC[1] += Assembling_fee[i] * quantityT[i];
                case "smart_watch" -> totPriceC[2] += Assembling_fee[i] * quantityT[i];
            }
        }
        for (int i = 0; i < n; i++) {
            switch (categoryT[i]) {
                case "phone" -> totQuantityC[0] += quantityT[i];
                case "laptop" -> totQuantityC[1] += quantityT[i];
                case "smart_watch" -> totQuantityC[2] += quantityT[i];
            }
        }
        for (int i = 0; i < n; i++) {
            switch (categoryT[i]) {
                case "phone" -> totEnergy_and_Device_CostC[0] += Energy_and_Device_Cost[i];
                case "laptop" -> totEnergy_and_Device_CostC[1] += Energy_and_Device_Cost[i];
                case "smart_watch" -> totEnergy_and_Device_CostC[2] += Energy_and_Device_Cost[i];

            }
        }
        // Your code ends here.
        // TODO: Calculate & Print Category-wise Statistics
        // Your code starts here:
        for (int i = 0; i < 3; i++) {
            System.out.println(categoriesList[i]);
            System.out.println(totQuantityC[i]);
            double avgAssemblingFee = totPriceC[i] / totQuantityC[i];
            System.out.printf("%.2f\n", avgAssemblingFee);
            double[] netProfit = new double[categoriesList.length];
            netProfit[i] = (totPriceC[i] - (16 * totAssembling_TimeC[i]) - totEnergy_and_Device_CostC[i]) / totQuantityC[i];
            System.out.printf("%.2f\n", netProfit[i]);
            }
        }

		// Your code ends here.
    // TODO: Find index of item with the highest price per unit.
    static int getMaxPriceIndex(double[] priceT){
		// Your code starts here:
        int maxIndex = 0;
        double maxPrice = priceT[0];
        for (int i=0; i < priceT.length; i++) {
            if (priceT[i] > maxPrice) {
                maxPrice = priceT[i];
                maxIndex = i;
            }
        }
        return maxIndex; // modify this as well
		// Your code ends here.
    }

    // TODO: Find index of item with the lowest price per unit.
    static int getMinPriceIndex(double[] priceT){
		// Your code starts here:
        int minIndex = 0;
        double minPrice = priceT[0];
        for (int i = 1; i < priceT.length; i++){
            if (priceT[i] < minPrice) {
                minPrice = priceT[i];
                minIndex = i;
            }
        }
        return minIndex; // modify this as well
		// Your code ends here.
    }
}
