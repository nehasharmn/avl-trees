package assn04;

public class Main {
  public static void main(String[] args) {
    NonEmptyBST<Integer> tree = new NonEmptyBST<>(4);

    tree.insert(2);
    tree.insert(6);
    tree.insert(1);
    tree.insert(3);
    tree.insert(5);
    tree.insert(7);

    System.out.println("Pre-order traversal");
    tree.printPreOrderTraversal();
    System.out.println();

    System.out.println("Post-order traversal");
    tree.printPostOrderTraversal();
    System.out.println();

    int min = tree.findMin();
    System.out.println("Minimum " + min);

    // Remove elements
    tree = (NonEmptyBST<Integer>) tree.remove(3);
    tree = (NonEmptyBST<Integer>) tree.remove(5);

    System.out.println("Pre-order traversal removal");
    tree.printPreOrderTraversal();
    System.out.println();

    System.out.println("Post-order traversal removal");
    tree.printPostOrderTraversal();
    System.out.println();

  }
}

//public class Main {
//  public static void main(String[] args) {
//    /*
//    This is a basic example of how to create a BST and add values
//    to it (which have been commented out).
//    You should add more examples and use this class to debug your code
//    */
//    BST<Integer> bst = new NonEmptyBST<Integer>(5);
//
////      bst = bst.insert(8);
////      bst = bst.insert(1);
////      bst = bst.insert(9);
////      bst = bst.insert(4);
//      bst.printPreOrderTraversal();
//
//
//  }
//}





